# used for discarding changes between some lines in main.tex
cp main.tex main.tex.bak && \
awk -v start=134 -v end=302 'NR==FNR{if(NR>=start && NR<=end) lines[NR]=$0; next}
NR>=start && NR<=end{$0=lines[NR]} 1' <(git show HEAD:main.tex) main.tex > main.tex.tmp && \
mv main.tex.tmp main.tex